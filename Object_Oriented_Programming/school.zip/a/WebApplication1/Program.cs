using System;
using System.Linq.Expressions;

class Program
{
    static void Main(string[] args)
    {
        Student student1 = new Student("John Richard", 20, "Sophomore", "Computer Science", 3.5);
        Student student2 = new Student("Jane Smith", 22, "Senior", "Mathematics", 3.8);

        student1.SetStudentID("S12345");
        student1.SetEmail("john@gmail.com");

        student2.SetStudentID("S67890");
        student2.SetEmail("jane@gmail.com");

        student1.Study();
        student1.TakeExam();
        student1.PrintStudentDetails();

        student2.Study();
        student2.TakeExam();
        student2.PrintStudentDetails();

        Teacher teacher1 = new Teacher("Mr. Robert", 40, "Pyshics", "T001");
        Teacher teacher2 = new Teacher("Ms. Turner", 35, "Mathematics", "T002");
        Teacher teacher3 = new Teacher("Dr. Johson", 50, "Chemistry", "T003");

        teacher1.SetYearsOfExperience(15);
        teacher1.SetEmail("roberts@school.com");
        teacher1.SetPhoneNumber("5569-999");

        teacher2.SetYearsOfExperience(10);
        teacher2.SetEmail("turner@school.com");
        teacher2.SetPhoneNumber("5569-999");

        teacher3.SetYearsOfExperience(20);
        teacher3.SetEmail("johnson@school.com");
        teacher3.SetPhoneNumber("5569-999");

        teacher1.Teach();
        teacher1.PrintTeacherDetails();

        teacher2.Teach();
        teacher2.PrintTeacherDetails();

        teacher3.Teach();
        teacher3.PrintTeacherDetails();

        Console.WriteLine("End of school Project.");
    }
}        

