using System;

public class Teacher
{
    public string Name { get; set; }
    public int Age { get; set; }
    public string Subject { get; set; }
    public string EmployeeID { get; set; }
    public int YearsOfExperience { get; set; }
    public string Email { get; set; }
    public string PhoneNumber {get; set; }

    public Teacher(string name, int age, string subject, string employeeID)
    {
        Name = name;
        Age = age;
        Subject = subject;
        EmployeeID = employeeID;
        YearsOfExperience = 0;
        Email = "Not Assigned";
        PhoneNumber = "Not Assigned";
    }

    public void SetYearsOfExperience(int years)
    {
        YearsOfExperience = years;
    }

    public void SetEmail(string email)
    {
        Email = email;
    }

    public void SetPhoneNumber(string phoneNumber)
    {
        PhoneNumber = phoneNumber;
    }

    public void Teach()
    {
        Console.WriteLine($"{Name} is teaching {Subject}.");
    }

    public void PrintTeacherDetails()
    {
        Console.WriteLine($"Name: {Name}, Age: {Age}, Subject: {Subject}, EmployeeID: {EmployeeID}, Years of Experience: {YearsOfExperience}, Email: {Email}, Phone: {PhoneNumber}");
    }
}
                    

