using System;

public class Student
{

    public string Name { get; set; }
    public int Age { get; set; }
    public string Grade { get; set; }
    public string Major { get; set; }
    public double GPA { get; set; }
    public string StudentID { get; set; }
    public string Email { get; set; }

    public Student(string name, int age, string grade, string major, double gpa)
    {
        Name = name;
        Age = age;
        Grade = grade;
        Major = major;
        GPA = gpa;
        StudentID = "Not Assigned";
        Email = "Not Assigned";
    }

    public void SetStudentID(string studentID)
    {
        StudentID = studentID;
    }

    public void SetEmail(string email)
    {
        Email = email;
    }

    public void Study()
    {
        Console.WriteLine($"{Name} is studying.");
    }

    public void TakeExam()
    {
        Console.WriteLine($"{Name} is taking an exam.");
    }

    public void PrintStudentDetails()
    {
        Console.WriteLine($"Name: {Name}, Age: {Age}, Grade: {Grade}, Major: {Major}, GPA: {GPA}, StudentID: {StudentID}, Email: {Email}");
    }                
}
    
